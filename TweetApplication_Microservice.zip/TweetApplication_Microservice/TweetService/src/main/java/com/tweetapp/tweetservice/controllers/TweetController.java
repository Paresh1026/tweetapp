package com.tweetapp.tweetservice.controllers;

import com.tweetapp.tweetservice.entities.Tweets;
import com.tweetapp.tweetservice.services.TweetService;

//import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
//import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
//import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class TweetController {

    @Autowired
    private TweetService userService;

    private Logger logger = LoggerFactory.getLogger(TweetController.class);

    //create
    @PostMapping
    public ResponseEntity<Tweets> createUser(@RequestBody Tweets user) {
        Tweets user1 = userService.saveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);
    }

    //single user get


    @GetMapping("/{userId}")

    public ResponseEntity<Tweets> getSingleUser(@PathVariable String userId) {
        logger.info("Get Single User Handler: UserController");
        Tweets user = userService.getUser(userId);
        return ResponseEntity.ok(user);
    }


    //all user get
    @GetMapping
    public ResponseEntity<List<Tweets>> getAllUser() {
        List<Tweets> allUser = userService.getAllUser();
        return ResponseEntity.ok(allUser);
    }
}
