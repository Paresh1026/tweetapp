package com.tweetapp.tweetservice.services;

import java.util.List;

import com.tweetapp.tweetservice.entities.Tweets;

public interface TweetService {

    //user operations

    //create
    Tweets saveUser(Tweets user);

    //get all user
    List<Tweets> getAllUser();

    //get single user of given userId

    Tweets getUser(String userId);

    //TODO: delete
    //TODO: update


}
