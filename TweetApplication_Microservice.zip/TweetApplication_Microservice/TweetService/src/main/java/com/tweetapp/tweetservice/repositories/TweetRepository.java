package com.tweetapp.tweetservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tweetapp.tweetservice.entities.Tweets;

public interface TweetRepository extends JpaRepository<Tweets,String>
{
   
}
