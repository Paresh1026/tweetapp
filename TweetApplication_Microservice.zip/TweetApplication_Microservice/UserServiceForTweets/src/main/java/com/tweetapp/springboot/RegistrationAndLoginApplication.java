package com.tweetapp.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaClient
public class RegistrationAndLoginApplication {


	public static void main(String[] args) {
		SpringApplication.run(RegistrationAndLoginApplication.class, args);
	}



}
